//
// Created by Maik Schmidt on 31.03.23.
//
#pragma once

unsigned int ackermann (unsigned int n,unsigned int m);

